package com.app.base.application

import Preferences
import android.app.Application
import android.content.Context
import android.os.StrictMode
import android.os.StrictMode.VmPolicy


class Application : Application() {

    var mContext: Context? = null


    companion object AppContext {
        lateinit var instance: com.app.base.application.Application
         fun getContext(): Context {
            return instance
        }
    }

    init {
        instance = this
    }


    override fun onCreate() {
        super.onCreate()
        Preferences.initPreferences(this)
        mContext = applicationContext
        /*val builder = VmPolicy.Builder()
        StrictMode.setVmPolicy(builder.build())*/
    }


}
