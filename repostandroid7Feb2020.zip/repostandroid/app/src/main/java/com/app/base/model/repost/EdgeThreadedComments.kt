package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeThreadedComments(

	@field:SerializedName("page_info")
	val pageInfo: PageInfo? = null,

	@field:SerializedName("count")
	val count: Int? = null,

	@field:SerializedName("edges")
	val edges: List<Any?>? = null
)