package com.app.base.storage

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.viewModelScope
import com.app.base.storage.database.RepostDatabase
import com.app.base.storage.entity.PostEntity
import kotlinx.coroutines.launch

/**
 * This is the part of lifecycle library;
 * this will help you to provide data between repository and UI.
 * This survives the data on configuration changes and gets the existing ViewModel to reconnect
 * with the new instance of the owner.
 */
class StorageViewModel(application: Application) : AndroidViewModel(application) {


    private val repository: StorageRepository
    val allPost: LiveData<MutableList<PostEntity>>

    val post = MediatorLiveData<List<PostEntity>>()

    init {
        val factDao = RepostDatabase.getInstance(application)!!.postDao()
        repository = StorageRepository(factDao)
        allPost = repository.allPost
    }

    fun insertPost(post: PostEntity) = viewModelScope.launch {
        repository.insert(post)
    }


    fun getAllPost() = viewModelScope.launch {
        post.postValue(repository.getAllFacts())
    }


}