package com.app.base.base

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Build
import android.provider.MediaStore
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Window
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.app.base.R
import com.app.base.utils.Utils


@SuppressLint("Registered")
abstract class BaseActivity : AppCompatActivity() {
    protected val TAG: String = javaClass.simpleName
    private var mProgressDialog: Dialog? = null


    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun backGroundColor() {
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        window.navigationBarColor = ContextCompat.getColor(this, android.R.color.transparent)
        window.setBackgroundDrawableResource(R.drawable.top_bar_gradient)
    }

    fun showSnackBar(message: String) {
        this.let {
            Snackbar.make(window.decorView.rootView, message, Snackbar.LENGTH_LONG).show()
        }
    }


    override fun onPause() {
        super.onPause()
        Utils.hideKeyboard(this)
    }

//    override fun onStart() {
//        super.onStart()
//        Utils.hideKeyboard(this)
//    }


    fun replaceFragment(fragment: androidx.fragment.app.Fragment, container: Int) {
        val tag: String = fragment::class.java.simpleName
        val transaction = supportFragmentManager?.beginTransaction()
        transaction?.setCustomAnimations(R.anim.fade_in,
                R.anim.fade_out)
        transaction?.replace(container, fragment, tag)
                ?.commitAllowingStateLoss()
    }


    /**
     * Add fragment with or without addToBackStack
     *
     * @param fragment       which needs to be attached
     * @param addToBackStack is fragment needed to backstack
     */
    fun addFragment(fragment: androidx.fragment.app.Fragment, addToBackStack: Boolean, container_id: Int) {
        val tag = fragment.javaClass.simpleName
        val fragmentManager = this.supportFragmentManager
        val fragmentOldObject = fragmentManager.findFragmentByTag(tag)
        val transaction = fragmentManager.beginTransaction()
        transaction.setCustomAnimations(R.anim.anim_in, R.anim.anim_out, R.anim.anim_in_reverse, R.anim.anim_out_reverse)
        if (fragmentOldObject != null) {
            fragmentManager.popBackStackImmediate(tag, 0)
        } else {
            if (addToBackStack) {
                transaction.addToBackStack(tag)
            }
            transaction.add(container_id, fragment, tag)
                    .commit()
        }

    }

    private fun showProgress() {
        if (mProgressDialog == null) {
            mProgressDialog = Dialog(this, android.R.style.Theme_Translucent)
            mProgressDialog?.window!!.requestFeature(Window.FEATURE_NO_TITLE)
            mProgressDialog?.setContentView(R.layout.content_loader)
            mProgressDialog?.setCancelable(false)
        }
        mProgressDialog!!.show()
    }

    private fun hideProgress() {
        if (mProgressDialog != null && mProgressDialog!!.isShowing) {
            mProgressDialog!!.dismiss()
        }
    }

    fun showLoading(show: Boolean?) {
        if (show!!) showProgress() else hideProgress()
    }
}