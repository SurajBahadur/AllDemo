package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeMediaToTaggedUser(

	@field:SerializedName("edges")
	val edges: List<Any?>? = null
)