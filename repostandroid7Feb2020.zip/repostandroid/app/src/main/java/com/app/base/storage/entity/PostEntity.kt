package com.app.base.storage.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

/**
 *
post_id
post_typename
post_username
post_user_pic
post_caption
post_display_url
reposted_status

edge_sidecar_to_children
type
display_url

 */

@Entity(tableName = "PostEntity")
data class PostEntity(
        @PrimaryKey var postId: String,
        var postTypename: String,
        var postUsername: String,
        var postUserPic: String,
        var postCaption: String,
        var postDisplayUrl: String,
        var postRepostedStatus: Boolean,
        var postMedia: String,
        var postCreatedAt: Long

) : Serializable

