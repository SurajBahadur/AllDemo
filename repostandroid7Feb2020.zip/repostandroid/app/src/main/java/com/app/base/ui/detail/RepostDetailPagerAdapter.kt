package com.app.base.ui.detail

import android.net.Uri
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.MediaController
import androidx.fragment.app.FragmentActivity
import androidx.viewpager.widget.PagerAdapter
import com.app.base.R
import com.app.base.model.PostMedia
import com.app.base.utils.Constants
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_post_detail.view.*
import kotlinx.android.synthetic.main.item_repost.view.*

class RepostDetailPagerAdapter(private val context: FragmentActivity?, private val postMediaList: Array<PostMedia>) : PagerAdapter() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)


    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun getCount(): Int {
        return postMediaList.size
    }

    override fun instantiateItem(view: ViewGroup, position: Int): Any {
        val layout = inflater.inflate(R.layout.item_post_detail, view, false)!!

        if (postMediaList[position].mediaType == Constants.PostType.GRAPHVIDEO.type) {
            //video url
            layout.imageView.visibility = View.GONE
            layout.iv_play.visibility = View.VISIBLE
            layout.videoView.setVideoURI(Uri.parse(postMediaList[position].mediaUrl))
            layout.videoView.requestFocus()
            layout.videoView.seekTo(1)
            layout.videoView.setOnClickListener {
                if (layout.videoView.isPlaying) {
                    layout.iv_play.visibility = View.VISIBLE
                    layout.videoView.pause()
                } else {
                    layout.iv_play.visibility = View.GONE
                    layout.videoView.start()
                }
            }
        } else {
            //image url
            layout.iv_play.visibility = View.GONE
            layout.videoView.visibility = View.GONE
            Picasso.get().load(postMediaList[position].mediaUrl).fit().into(layout.imageView)
        }

        view.addView(layout, 0)

        return layout
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun restoreState(state: Parcelable?, loader: ClassLoader?) {}

    override fun saveState(): Parcelable? {
        return null
    }

}