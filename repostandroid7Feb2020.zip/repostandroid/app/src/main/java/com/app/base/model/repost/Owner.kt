package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class Owner(

	@field:SerializedName("id")
	val id: String? = null,

	@field:SerializedName("is_verified")
	val isVerified: Boolean? = null,

	@field:SerializedName("profile_pic_url")
	val profilePicUrl: String? = null,

	@field:SerializedName("username")
	val username: String? = null
)