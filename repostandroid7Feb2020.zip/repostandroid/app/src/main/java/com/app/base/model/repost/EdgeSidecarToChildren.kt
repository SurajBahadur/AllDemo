package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeSidecarToChildren(

	@field:SerializedName("edges")
	val edges: List<EdgesItem?>? = null
)