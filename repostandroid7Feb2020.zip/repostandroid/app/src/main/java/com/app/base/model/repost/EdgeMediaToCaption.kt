package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeMediaToCaption(

	@field:SerializedName("edges")
	val edges: List<EdgesItem?>? = null
)