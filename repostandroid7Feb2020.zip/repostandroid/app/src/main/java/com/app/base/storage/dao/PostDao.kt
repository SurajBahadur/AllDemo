package com.app.base.storage.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.app.base.storage.entity.PostEntity

/**
 * By using suspension keyword, our Dao class methods can execute without blocking the current thread.
 */
@Dao
interface PostDao {

    @Query("SELECT * FROM PostEntity ORDER BY postCreatedAt DESC")
    fun getAllPost(): LiveData<MutableList<PostEntity>>

    @Query("SELECT * FROM PostEntity ORDER BY postCreatedAt DESC")
    suspend fun getAllFact2(): List<PostEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Query("UPDATE PostEntity SET postRepostedStatus=:status WHERE postId=:id")
    suspend fun updatedRepostedStatus(status: Boolean, id: Int)

    @Query("SELECT * FROM PostEntity where postRepostedStatus=:status")
    suspend fun getPostListByStatus(status: Boolean): List<PostEntity>


}