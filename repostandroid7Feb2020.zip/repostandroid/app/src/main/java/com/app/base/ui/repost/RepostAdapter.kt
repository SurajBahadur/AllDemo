package com.app.base.ui.repost

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.base.R
import com.app.base.storage.entity.PostEntity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_repost.*
import kotlinx.android.synthetic.main.item_repost.view.*

class RepostAdapter(val list: List<PostEntity>, val listner: RepostFragment) : RecyclerView.Adapter<RepostAdapter.ViewHolder>() {


    var onPostClick: ((PostEntity) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_repost, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItem(list[position])
        holder.itemView.setOnClickListener {
            onPostClick?.invoke(list[position])
        }

    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        //will be use later
        fun bindItem(data: PostEntity) {
            itemView.tv_post_username.text = data.postUsername
            itemView.tv_post_description.text = data.postCaption
            Picasso.get().load(data.postUserPic).into(itemView.iv_post_user_image)
            Picasso.get().load(data.postDisplayUrl).into(itemView.iv_post_image)
        }
    }
}