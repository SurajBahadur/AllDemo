package com.app.base.activity

import android.os.Bundle
import com.app.base.R
import com.app.base.base.BaseActivity
import com.app.base.ui.repost.RepostFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        backGroundColor()
        attachClickListener()
        addFragment(RepostFragment(), false, R.id.container_main)
    }
    /**
     * Method to handle the click on repost,story,schedule and hashtag option
     */
    private fun attachClickListener() {
        navigation.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.tab_repost -> {
                    replaceFragment(RepostFragment(), R.id.container_main)
                }

                R.id.tab_story -> {
                    showSnackBar(getString(R.string.under_development))
                }

                R.id.tab_schedule -> {
                    showSnackBar(getString(R.string.under_development))
                }

                R.id.tab_hashtags -> {
                    showSnackBar(getString(R.string.under_development))
                }
            }
            false
        }
    }
}
