package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeWebMediaToRelatedMedia(

	@field:SerializedName("edges")
	val edges: List<Any?>? = null
)