package com.app.base.model.repost

import com.google.gson.annotations.SerializedName


/**
 *  __typename": "GraphImage,
 *  __typename": "GraphSidecar
 *  __typename":  "GraphVideo
 */
data class PostDetailResponse(

        @field:SerializedName("graphql")
        val graphql: Graphql? = null
)