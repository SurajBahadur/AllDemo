package com.app.base.ui.detail


import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.viewpager.widget.ViewPager
import com.app.base.R
import com.app.base.base.BaseFragment
import com.app.base.model.PostMedia
import com.app.base.storage.entity.PostEntity
import com.app.base.utils.Constants
import com.google.gson.Gson
import com.karumi.dexter.Dexter
import com.karumi.dexter.DexterBuilder
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.fragment_repost_detail.*
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.jar.Manifest


/**
 * For showing details of post
 * https://gist.github.com/michaeltys/a8613e5aea9db8e4684bf85568e40160
 */
class RepostDetailFragment : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_repost_detail, container, false)
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getDataFromBundle()
        attachClickListener()
    }

    private fun attachClickListener() {
        tv_back.setOnClickListener {
            activity!!.onBackPressed()
        }

        btn_repost.setOnClickListener {
            sharingImageToFeed()
        }
    }

    /**
     * https://developers.facebook.com/docs/instagram/sharing-to-stories/
     * https://developers.facebook.com/docs/instagram/sharing-to-feed
     */

    private fun sharingImageToFeed() {
        Log.d("ttttttttt", image)
        if (askStoragePermission()) {
            DownloadTaskImage().execute(image)
        }
    }

    private fun askStoragePermission(): Boolean {
        var status = false
        Dexter.withActivity(activity!!).withPermissions(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        ).withListener(object : MultiplePermissionsListener {
            override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                status = report!!.areAllPermissionsGranted()
            }

            override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {

            }

        }).check()

        return status
    }


    lateinit var image: String
    lateinit var type: String
    /**
     * Method called to retrieve single post detail passed from the RepostFragment
     */
    private fun getDataFromBundle() {
        val list: PostEntity = arguments!!.getSerializable("data") as PostEntity
        val gson = Gson()
        val postMediaList: Array<PostMedia> = gson.fromJson(list.postMedia, Array<PostMedia>::class.java)

        image = postMediaList[0].mediaUrl
        pager.adapter = RepostDetailPagerAdapter(activity, postMediaList)
        if (postMediaList.size == 1) {
            dot_indicator.visibility = View.GONE
        } else {
            dot_indicator.initDots(postMediaList.size + 1)
            pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                override fun onPageScrollStateChanged(state: Int) {
                }

                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                }

                override fun onPageSelected(position: Int) {
                    dot_indicator.setDotSelection(position + 1)
                    image = postMediaList[position].mediaUrl
                    type = postMediaList[position].mediaType
                }

            })
        }
    }


    /**
     * Method to download image
     */
    @SuppressLint("StaticFieldLeak")
    inner class DownloadTaskImage : AsyncTask<String, String, String>() {
        private var progressDialog: ProgressDialog? = null
        private var fileName: String? = null
        private var folder: String? = null

        override fun onPreExecute() {
            super.onPreExecute()
            progressDialog = ProgressDialog(activity)
            progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
            progressDialog!!.setCancelable(false)
            progressDialog!!.show()
        }

        override fun doInBackground(vararg f_url: String?): String {
            var count: Int = 0
            try {
                val url = URL(f_url[0])
                val connection = url.openConnection()
                connection.connect()
                // getting file length
                val lengthOfFile = connection.contentLength


                // input stream to read file - with 8k buffer
                val input = BufferedInputStream(url.openStream(), 8192)
                //Extract file name from URL
                fileName = f_url[0]?.substring(f_url[0]!!.lastIndexOf('/') + 1, f_url[0]!!.length) + "tt"
                folder = Environment.getExternalStorageDirectory().toString() + File.separator + "Repost/" + "Images/"
                //Create TourGuide folder if it does not exist
                val directory = File(folder!!)
                if (!directory.exists()) {
                    directory.mkdirs()
                }
                // Output stream to write file
                val output = FileOutputStream(folder!! + fileName!!)
                val data = ByteArray(1024)
                var total: Long = 0
                while (count != -1) {
                    count = input.read(data)
                    total += count.toLong()
                    publishProgress("" + (total * 100 / lengthOfFile).toInt())
                    output.write(data, 0, count)
                }

                // flushing output
                output.flush()

                // closing streams
                output.close()
                input.close()
                return "$folder$fileName"

            } catch (e: Exception) {
                Log.e("Error: ", e.message)
            }

            return "$folder$fileName"
        }

        override fun onPostExecute(path: String?) {
            progressDialog!!.dismiss()
            var type = ""
            type = if (type == Constants.PostType.GRAPHIMAGE.type) {
                "image/*"
            } else {
                "video/*"
            }
            val mediaPath = Environment.getExternalStorageDirectory().absolutePath + File.separator + "Repost/" + "Images/$fileName"
            createInstagramIntent(type, mediaPath)

        }

        override fun onProgressUpdate(vararg progress: String?) {
            //progressDialog!!.progress = Integer.parseInt(progress[0]!!)
        }
    }


    private fun createInstagramIntent(type: String, mediaPath: String) {

        // Create the new Intent using the 'Send' action.
        val share = Intent(Intent.ACTION_SEND)

        // Set the MIME type
        share.type = type

        // Create the URI from the media
        val media = File(mediaPath)
        val uri: Uri = Uri.fromFile(media)


        //new approach
        val apkURI = FileProvider.getUriForFile(activity!!, context!!.applicationContext.packageName + ".provider", media)
        share.setDataAndType(apkURI, type)
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        //end of new approach


        // Add the URI to the Intent.
        share.putExtra(Intent.EXTRA_STREAM, apkURI)
        share.setPackage("com.instagram.android")

        // Broadcast the Intent.
        startActivity(Intent.createChooser(share, "Share to"))
    }

    /**
     * For futuer use
     */
    private fun shareFileToInstagram(uri: Uri, isVideo: Boolean) {
        Log.d("tttttttttts", uri.toString())
        val feedIntent = Intent(Intent.ACTION_SEND)
        feedIntent.type = if (isVideo) "video/*" else "image/*"
        feedIntent.putExtra(Intent.EXTRA_STREAM, uri)
        feedIntent.setPackage("com.instagram.android")

        val storiesIntent = Intent("com.instagram.share.ADD_TO_STORY")
        storiesIntent.setDataAndType(uri, if (isVideo) "mp4" else "jpg")
        storiesIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        storiesIntent.setPackage("com.instagram.android")
        activity!!.grantUriPermission("com.instagram.android", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)

        val chooserIntent = Intent.createChooser(feedIntent, "Testing ")
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(storiesIntent))
        startActivity(chooserIntent)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("ttttt,", "onActivityResult")
    }






}
