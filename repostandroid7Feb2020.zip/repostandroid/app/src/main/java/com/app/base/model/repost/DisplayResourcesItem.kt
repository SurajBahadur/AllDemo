package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class DisplayResourcesItem(

	@field:SerializedName("src")
	val src: String? = null,

	@field:SerializedName("config_height")
	val configHeight: Int? = null,

	@field:SerializedName("config_width")
	val configWidth: Int? = null
)