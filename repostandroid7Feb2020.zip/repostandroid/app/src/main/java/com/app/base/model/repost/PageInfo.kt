package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class PageInfo(

	@field:SerializedName("has_next_page")
	val hasNextPage: Boolean? = null,

	@field:SerializedName("end_cursor")
	val endCursor: Any? = null
)