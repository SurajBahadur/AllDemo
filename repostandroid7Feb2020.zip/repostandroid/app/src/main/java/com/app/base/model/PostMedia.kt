package com.app.base.model

data class PostMedia(val mediaType: String, val mediaUrl: String)