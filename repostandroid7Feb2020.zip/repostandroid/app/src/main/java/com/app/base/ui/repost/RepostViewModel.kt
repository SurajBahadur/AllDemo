package com.app.base.ui.repost

import androidx.lifecycle.MutableLiveData
import com.app.base.api.model.MyViewModel
import com.app.base.model.repost.PostDetailResponse

class RepostViewModel : MyViewModel() {

    var response = MutableLiveData<PostDetailResponse>()

    fun getInstagramPostDetails(postId: String) {
        isLoading.value = true
        RepostRepository.getInstagramPostDetails({
            response.value = it
            isLoading.value = false
        }, {
            apiError.value = it
            isLoading.value = false
        }, {
            onFailure.value = it
            isLoading.value = false
        }, postId)
    }


}
