package com.app.base.storage.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.app.base.storage.dao.PostDao
import com.app.base.storage.entity.PostEntity


@Database(entities = [PostEntity::class], version = 2, exportSchema = true)
abstract class RepostDatabase : RoomDatabase() {

    abstract fun postDao(): PostDao

    companion object {
        private var INSTANCE: RepostDatabase? = null
        fun getInstance(context: Context): RepostDatabase? {
            if (INSTANCE == null) {
                synchronized(RepostDatabase::class) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            RepostDatabase::class.java, "repost.db")
                            .fallbackToDestructiveMigration()
                            .build()
                }
            }
            return INSTANCE
        }

        fun destroyInstance() {
            INSTANCE = null
        }
    }

}