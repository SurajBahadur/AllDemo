package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeLikedBy(

	@field:SerializedName("count")
	val count: Int? = null
)