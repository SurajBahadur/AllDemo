package com.app.base.utils

import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.net.ConnectivityManager
import android.util.TypedValue
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import com.app.base.R
import com.app.base.utils.security.SharedPreferencesEncryption
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import kotlin.math.roundToInt


object Utils {


    fun hideKeyboard(activity: Activity) {
        val view = activity.findViewById<View>(android.R.id.content)
        if (view != null) {
            val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }


    /**
     * Show toast.
     *
     * @param toast String value which needs to shown in the toast.
     * @description if you want to print a toast just call this method and pass
     * what you want to be shown.
     */
    @Synchronized
    fun showSnackbar(content: View?, toast: String) {
        val snackbar = Snackbar.make(content!!, toast, Snackbar.LENGTH_LONG)
        val snackbarView = snackbar.view
        val tv = snackbarView.findViewById<TextView>(R.id.snackbar_text)
        tv.maxLines = 3
        snackbar.duration = BaseTransientBottomBar.LENGTH_SHORT

        snackbar.show()

    }

    /**
     * Is online.
     *
     * @return True, if device is having a Internet connection available.
     */
    fun isNetworkAvailable(content: View?): Boolean {
        val cm = content?.context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        if (netInfo != null && netInfo.isConnectedOrConnecting) {
            return true
        } else {

            showSnackbar(content, content.context.getString(R.string.no_internet_message))
        }
        return false
    }

    @Synchronized
    fun getValue(key: String, defaultValue: String, context: Context?): String? {
        if (context == null) return null
        val prefs = SharedPreferencesEncryption(context)
        return prefs.getString(key, defaultValue)
    }


    fun dpToPx(dp: Int): Int {
//        return (dp * Resources.getSystem().displayMetrics.density) as Int
        return (dp * Resources.getSystem().displayMetrics.density).roundToInt()
    }

    fun pxToDp(px: Int): Int {
        return (px / Resources.getSystem().displayMetrics.density) as Int

    }

    fun spToPx(sp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, Resources.getSystem().displayMetrics)
    }


}