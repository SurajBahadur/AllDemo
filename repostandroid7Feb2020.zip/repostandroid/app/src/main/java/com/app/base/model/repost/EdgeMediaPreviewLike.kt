package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeMediaPreviewLike(

	@field:SerializedName("count")
	val count: Int? = null,

	@field:SerializedName("edges")
	val edges: List<Any?>? = null
)