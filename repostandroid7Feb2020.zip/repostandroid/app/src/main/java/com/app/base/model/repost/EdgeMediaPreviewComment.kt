package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class EdgeMediaPreviewComment(

	@field:SerializedName("count")
	val count: Int? = null,

	@field:SerializedName("edges")
	val edges: List<EdgesItem?>? = null
)