package com.app.base.storage

import androidx.lifecycle.LiveData
import com.app.base.storage.dao.PostDao
import com.app.base.storage.entity.PostEntity

/**
 * This is a class where we will check whether to fetch data from API or local database,
 * or you can say we are putting the logic of database fetching in this class.
 */
class StorageRepository(private var postDao: PostDao) {

    val allPost: LiveData<MutableList<PostEntity>> = postDao.getAllPost()

    suspend fun insert(post: PostEntity) {
        postDao.insertPost(post)
    }

    suspend fun getAllFacts(): List<PostEntity> {
        return postDao.getAllFact2()
    }

    suspend fun updatedRepostedStatus(status: Boolean, id: Int) {
        postDao.updatedRepostedStatus(status, id)
    }

    suspend fun getFavFacts(): List<PostEntity> {
        return postDao.getPostListByStatus(true)
    }
}