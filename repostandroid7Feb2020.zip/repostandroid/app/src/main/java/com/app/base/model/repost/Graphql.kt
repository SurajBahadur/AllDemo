package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class Graphql(

	@field:SerializedName("shortcode_media")
	val shortcodeMedia: ShortcodeMedia? = null
)