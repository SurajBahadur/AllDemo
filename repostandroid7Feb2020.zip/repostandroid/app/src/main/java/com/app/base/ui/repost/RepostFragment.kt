package com.app.base.ui.repost

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.base.R
import com.app.base.base.BaseFragment
import com.app.base.model.PostMedia
import com.app.base.model.repost.ShortcodeMedia
import com.app.base.storage.StorageViewModel
import com.app.base.storage.entity.PostEntity
import com.app.base.ui.detail.RepostDetailFragment
import com.app.base.utils.Constants
import com.google.gson.Gson
import kotlinx.android.synthetic.main.content_repost.*
import kotlinx.android.synthetic.main.fragment_repost.*


/**
 * This class will handle all the functionalities of repost category
 */
class RepostFragment : BaseFragment(), View.OnClickListener {

    private lateinit var mRepostAdapter: RepostAdapter
    private lateinit var mViewModel: RepostViewModel //view model for REST APIs
    private lateinit var mStorageViewModel: StorageViewModel //view model for local storage
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_repost, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mViewModel = ViewModelProviders.of(this).get(RepostViewModel::class.java)
        mStorageViewModel = ViewModelProviders.of(this).get(StorageViewModel::class.java)
        attachClickListener()
        attachObservers()
        getAllPostList()
    }


    /**
     * Method call to get the list of post
     */
    private fun getAllPostList() {
        mStorageViewModel.getAllPost()
    }

    override fun onResume() {
        super.onResume()
        showCopyLink()
    }

    /**
     * Method will called automatically whenever there is changes in the livedata
     * Post response receive from the instagram will have below types
     *  __typename": "GraphImage, contain single image
     *  __typename": "GraphSidecar contain multiple either multiple images and videos or mixed of both
     *  __typename":  "GraphVideo contain single video
     *  val timerPojo: TourTimePojo = gson.fromJson(timerJsonData, TourTimePojo::class.java)
     */
    private fun attachObservers() {
        mViewModel.response.observe(this, Observer {
            it.graphql!!.shortcodeMedia?.let { it1 -> handlePostResponse(it1) }
        })

        mStorageViewModel.allPost.observe(this, Observer {
            initRepostAdapter(it)
        })
    }

    /**
     * Method called to handle response of instagram post
     * res contain the response
     */
    private fun handlePostResponse(res: ShortcodeMedia) {
        val list = ArrayList<PostMedia>()
        if (res.typename!! == Constants.PostType.GRAPHIMAGE.type) {
            //POST CONTAIN SINGLE IMAGE
            list.add(PostMedia(res.typename, res.displayUrl!!))
            insertPostLinkStorage(res, list)
        } else if (res.typename == Constants.PostType.GRAPHSIDEBAR.type) {
            //POST CONTAIN EITHER MULTIPLE IMAGE OR VIDEO OR COMBINATION OF BOTH
            val mediaList = res.edgeSidecarToChildren!!.edges!!
            for (data in mediaList) {
                if (data!!.node!!.typename == Constants.PostType.GRAPHVIDEO.type) {
                    //contain image
                    list.add(PostMedia(data.node!!.typename!!, data.node.videoUrl!!))
                } else {
                    //contain video
                    list.add(PostMedia(data.node!!.typename!!, data.node.displayUrl!!))
                }
            }
            insertPostLinkStorage(res, list)
        } else if (res.typename == Constants.PostType.GRAPHVIDEO.type) {
            //POST CONTAIN SINGLE VIDEO
            list.add(PostMedia(res.typename, res.videoUrl!!))
            insertPostLinkStorage(res, list)
        }

    }

    /**
     * Called to insert post details into the local storage
     */
    private fun insertPostLinkStorage(res: ShortcodeMedia, list: ArrayList<PostMedia>) {
        mStorageViewModel.insertPost(PostEntity(
                postId = res.id!!,
                postTypename = res.typename!!,
                postUsername = res.owner!!.username!!,
                postUserPic = res.owner.profilePicUrl!!,
                postCaption = res.edgeMediaToCaption!!.edges!![0]!!.node!!.text!!,
                postDisplayUrl = res.displayUrl!!,
                postRepostedStatus = false,
                postMedia = Gson().toJson(list),
                postCreatedAt = System.currentTimeMillis()
        ))

    }


    /**
     * Method called to get the instagram post id from the copied url
     * and then call the REST APIs to fetch post details
     */
    private fun showCopyLink() {
        val clipboard = activity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        if (clip != null) {
            val pasteUri: String = clip.run {
                val item: ClipData.Item = getItemAt(0)
                item.text.toString()
            }
            if (pasteUri.contains("instagram")) {
                Log.d("tttdt", "$pasteUri")
                try {
                    val postId = pasteUri.split("/")[4]
                    if (postId != getPostLinkId()) {
                        mViewModel.getInstagramPostDetails(postId)
                        savePostLinkId(postId)
                    }
                } catch (e: java.lang.Exception) {

                }
            }
        }
    }


    /**
     * Method called to set listener in buttons
     */
    private fun attachClickListener() {
        btn_allow.setOnClickListener(this)
        btn_not_reposted.setOnClickListener(this)
        iv_insta_icon.setOnClickListener(this)
    }

    //Method called to initialize and populate data in adapter
    private fun initRepostAdapter(list: List<PostEntity>) {
        rv_repost_list.layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false) as RecyclerView.LayoutManager?
        mRepostAdapter = RepostAdapter(list, this)
        rv_repost_list.adapter = mRepostAdapter
        rv_repost_list.startAnimation(AnimationUtils.loadAnimation(activity, R.anim.fade_in))

        mRepostAdapter.onPostClick = {
            val fragment = RepostDetailFragment()
            val bundle = Bundle()
            bundle.putSerializable("data", it)
            fragment.arguments = bundle
            addFragment(fragment, true, R.id.container_full)
        }
    }

    /**
     * Method called to handle the click events
     */
    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.btn_allow -> {
                changeButtonBackground(btn_allow.text.toString())
                showCopyLink()
            }
            R.id.btn_not_reposted -> {
                changeButtonBackground(btn_not_reposted.text.toString())
            }
            R.id.iv_insta_icon -> {
                launchInstagramApp()
            }
        }
    }

    /**
     * Method called to launch the external instagram
     */
    private fun launchInstagramApp() {
        try {
            val launchIntent: Intent = activity!!.packageManager.getLaunchIntentForPackage("com.instagram.android")!!
            startActivity(launchIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Please installed intagram application first", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Method called to changed background color
     * btn_name hold the name
     */
    private fun changeButtonBackground(btn_name: String) {
        if (btn_name == "All Posts") {
            btn_allow.setBackgroundResource(R.drawable.btn_allow_bg)
            val drawable = btn_allow.background as GradientDrawable
            drawable.setColor(Color.parseColor("#007AFE"))
            btn_allow.setTextColor(Color.WHITE)
            btn_not_reposted.setBackgroundResource(R.drawable.btn_not_reposted_bg)
            val drawable2 = btn_not_reposted.background as GradientDrawable
            drawable2.setColor(Color.parseColor("#FFFFFF"))
            btn_not_reposted.setTextColor(Color.parseColor("#007AFE"))
        } else {
            btn_not_reposted.setBackgroundResource(R.drawable.btn_not_reposted_bg)
            val drawable = btn_not_reposted.background as GradientDrawable
            drawable.setColor(Color.parseColor("#007AFE"))
            btn_not_reposted.setTextColor(Color.WHITE)
            btn_allow.setBackgroundResource(R.drawable.btn_allow_bg)
            val drawable2 = btn_allow.background as GradientDrawable
            drawable2.setColor(Color.parseColor("#FFFFFF"))
            btn_allow.setTextColor(Color.parseColor("#007AFE"))
        }
    }
}


