package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class Node(

        @field:SerializedName("text")
        val text: String? = null,
        @field:SerializedName("__typename")
        val typename: String? = null,
        @field:SerializedName("display_url")
        val displayUrl: String? = null,
        @field:SerializedName("video_url")
        val videoUrl: String? = null
)