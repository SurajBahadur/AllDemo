package com.app.base.model.repost

import com.google.gson.annotations.SerializedName

data class ShortcodeMedia(

        @field:SerializedName("display_url")
        val displayUrl: String? = null,

        @field:SerializedName("tracking_token")
        val trackingToken: String? = null,

        @field:SerializedName("viewer_has_liked")
        val viewerHasLiked: Boolean? = null,

        @field:SerializedName("__typename")
        val typename: String? = null,

        @field:SerializedName("viewer_has_saved")
        val viewerHasSaved: Boolean? = null,

        @field:SerializedName("viewer_has_saved_to_collection")
        val viewerHasSavedToCollection: Boolean? = null,

        @field:SerializedName("edge_web_media_to_related_media")
        val edgeWebMediaToRelatedMedia: EdgeWebMediaToRelatedMedia? = null,

        @field:SerializedName("shortcode")
        val shortcode: String? = null,

        @field:SerializedName("gating_info")
        val gatingInfo: Any? = null,

        @field:SerializedName("id")
        val id: String? = null,

        @field:SerializedName("fact_check_information")
        val factCheckInformation: Any? = null,

        @field:SerializedName("comments_disabled")
        val commentsDisabled: Boolean? = null,

        @field:SerializedName("fact_check_overall_rating")
        val factCheckOverallRating: Any? = null,

        @field:SerializedName("edge_media_preview_like")
        val edgeMediaPreviewLike: EdgeMediaPreviewLike? = null,

        @field:SerializedName("owner")
        val owner: Owner? = null,

        @field:SerializedName("has_ranked_comments")
        val hasRankedComments: Boolean? = null,

        @field:SerializedName("taken_at_timestamp")
        val takenAtTimestamp: Int? = null,

        @field:SerializedName("is_ad")
        val isAd: Boolean? = null,

        @field:SerializedName("edge_media_to_parent_comment")
        val edgeMediaToParentComment: EdgeMediaToParentComment? = null,

        @field:SerializedName("edge_media_preview_comment")
        val edgeMediaPreviewComment: EdgeMediaPreviewComment? = null,

        @field:SerializedName("edge_media_to_sponsor_user")
        val edgeMediaToSponsorUser: EdgeMediaToSponsorUser? = null,

        @field:SerializedName("edge_media_to_tagged_user")
        val edgeMediaToTaggedUser: EdgeMediaToTaggedUser? = null,

        @field:SerializedName("display_resources")
        val displayResources: List<DisplayResourcesItem?>? = null,

        @field:SerializedName("viewer_can_reshare")
        val viewerCanReshare: Boolean? = null,

        @field:SerializedName("is_video")
        val isVideo: Boolean? = null,

        @field:SerializedName("edge_sidecar_to_children")
        val edgeSidecarToChildren: EdgeSidecarToChildren? = null,

        @field:SerializedName("media_preview")
        val mediaPreview: Any? = null,

        @field:SerializedName("caption_is_edited")
        val captionIsEdited: Boolean? = null,

        @field:SerializedName("video_url")
        val videoUrl: String? = null,

        @field:SerializedName("location")
        val location: Any? = null,

        @field:SerializedName("edge_media_to_caption")
        val edgeMediaToCaption: EdgeMediaToCaption? = null,

        @field:SerializedName("dimensions")
        val dimensions: Dimensions? = null,

        @field:SerializedName("viewer_in_photo_of_you")
        val viewerInPhotoOfYou: Boolean? = null
)