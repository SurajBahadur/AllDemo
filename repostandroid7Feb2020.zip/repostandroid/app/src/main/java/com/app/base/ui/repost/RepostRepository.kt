package com.app.base.ui.repost

import com.app.base.api.service.ApiHelper
import com.app.base.model.repost.PostDetailResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object RepostRepository {

    private val webService = ApiHelper.createService()

    fun getInstagramPostDetails(successHandler: (PostDetailResponse) -> Unit,
                                failureHandler: (String) -> Unit,
                                onFailure: (Throwable) -> Unit,
                                postId: String) {
        webService.getInstagramPostDetails(postId).enqueue(object : Callback<PostDetailResponse> {
            override fun onResponse(call: Call<PostDetailResponse>?, response: Response<PostDetailResponse>?) {
                response?.body()?.let {
                    successHandler(it)
                }
            }

            override fun onFailure(call: Call<PostDetailResponse>?, t: Throwable?) {
                t?.let {
                    onFailure(it)
                }
            }
        })
    }

}