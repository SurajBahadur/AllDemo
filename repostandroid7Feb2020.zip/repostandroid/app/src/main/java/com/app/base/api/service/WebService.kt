package com.app.base.api.service


import com.app.base.model.repost.PostDetailResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path


/**
 * Interface to calling the REST APIs.
 */
interface WebService {

    //https://www.instagram.com/tv/B6LW6Wtli2O/?__a=1
    @Headers("Accept: " + "application/json")
    @GET("tv/{post_id}/?__a=1")
    fun getInstagramPostDetails(@Path("post_id") post_id: String?): Call<PostDetailResponse>

}