package com.app.base.utils


object Constants {

    //APIs base URL
    const val BASE_URL: String = "https://www.instagram.com/"
    const val LAST_POST_LINK_ID = "last_post_link_id"
    const val PERMISSION_REQUEST_CODE = 98
    const val HANDLER_DELAY_TIME: Long = 2000

    enum class PostType(val type: String) {
        GRAPHIMAGE("GraphImage"),
        GRAPHSIDEBAR("GraphSidecar"),
        GRAPHVIDEO("GraphVideo")
    }

}