package com.mangista.darling.Users;


import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.gmail.samehadar.iosdialog.IOSDialog;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.mangista.darling.Accounts.Login_A;
import com.mangista.darling.Chat.Chat_Activity;
import com.mangista.darling.CodeClasses.Functions;
import com.mangista.darling.CodeClasses.Variables;
import com.mangista.darling.InAppSubscription.InApp_Subscription_A;
import com.mangista.darling.Inbox.Match_Get_Set;
import com.mangista.darling.Main_Menu.MainMenuActivity;
import com.mangista.darling.Main_Menu.RelateToFragment_OnBack.RootFragment;
import com.mangista.darling.Matchs.Match_F;
import com.mangista.darling.Profile.Profile_Details.Profile_Details_F;
import com.mangista.darling.R;
import com.mangista.darling.Test.TestFragment;
import com.mangista.darling.callbacks.UserItemClicked;
import com.mangista.darling.sinch.SinchService;
import com.sinch.android.rtc.PushPair;
import com.sinch.android.rtc.Sinch;
import com.sinch.android.rtc.SinchClient;
import com.sinch.android.rtc.SinchError;
import com.sinch.android.rtc.calling.Call;
import com.sinch.android.rtc.calling.CallClient;
import com.squareup.picasso.Picasso;
import com.yarolegovich.discretescrollview.DSVOrientation;
import com.yarolegovich.discretescrollview.DiscreteScrollView;
import com.yarolegovich.discretescrollview.InfiniteScrollAdapter;
import com.yarolegovich.discretescrollview.transform.ScaleTransformer;
import com.yuyakaido.android.cardstackview.CardStackView;
import com.yuyakaido.android.cardstackview.SwipeDirection;
import com.zhouyou.view.seekbar.SignSeekBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.bclogic.pulsator4droid.library.PulsatorLayout;

import com.sinch.android.rtc.calling.CallClientListener;
import com.sinch.android.rtc.calling.CallListener;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * A simple {@link Fragment} subclass.
 */
public class Users_F extends RootFragment implements UserItemClicked, View.OnClickListener, DiscreteScrollView.OnItemChangedListener<RecyclerView.ViewHolder> {
    View view;
    Context context;
    CardStackView card_viewstack;
    ImageButton detail_btn;
    Button click_here;
    User_Adapter adapter;
    InfiniteScrollAdapter<UsersAdapter_New.ViewHolder> usersAdapter_new;
    ImageButton refresh_btn, cross_btn, heart_btn;
    IOSDialog iosDialog;
    public SinchClient mSinchClient;
    private static final String APP_KEY = "2daffd1e-2734-4e8a-931c-f19203647da5";
    private static final String APP_SECRET = "641j9LH1O0yEUAvG1HubHw==";
    private static final String ENVIRONMENT = "clientapi.sinch.com";
    private SinchService.StartFailedListener mListener;
    Animation animation,animation1;

    public Users_F() {
    }

    RelativeLayout user_list_layout, find_nearby_User;
    LinearLayout ll_callingData, ll_testData, ll_endCall, ll_searchingData;
    DatabaseReference rootref;
    boolean is_Api_running = false;
    boolean is_view_load = false;
    DiscreteScrollView discreteScrollView;
    ArrayList<Nearby_User_Get_Set> usersList = new ArrayList<Nearby_User_Get_Set>();
    ConstraintLayout cl_callData, cl_callDurationData;
    ImageView iv_call, iv_callReject, ivUserImage, iv_callEnd, iv_speakerOn, iv_speakerOff, ivMyImage, ivOtherImage;
    TextView tv_userName, tv_callDuration, tv_myName, tv_otherUserName;
    String receiverName = "";
    private Call call;
    private SinchClient sinchClient;
    private String callType = "";

    private long startTime = 0L;
    private Handler customHandler = new Handler();
    long timeInMilliseconds = 0L;
    long timeSwapBuff = 0L;
    long updatedTime = 0L;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_users, container, false);

        context = getContext();
        adapter = new User_Adapter(context);
        rootref = FirebaseDatabase.getInstance().getReference();
        ImageView profile_image = view.findViewById(R.id.profileimage);
        discreteScrollView = view.findViewById(R.id.rv_usersData);
        click_here = view.findViewById(R.id.click_here);
        ll_testData = view.findViewById(R.id.ll_testData);
        ll_callingData = view.findViewById(R.id.ll_callingData);
        cl_callData = view.findViewById(R.id.cl_callData);
        cl_callDurationData = view.findViewById(R.id.cl_callDurationData);
        iv_callReject = view.findViewById(R.id.iv_callReject);
        iv_call = view.findViewById(R.id.iv_call);
        ivUserImage = view.findViewById(R.id.ivUserImage);
        tv_userName = view.findViewById(R.id.tv_userName);
        ll_endCall = view.findViewById(R.id.ll_endCall);
        iv_callEnd = view.findViewById(R.id.iv_callEnd);
        iv_speakerOn = view.findViewById(R.id.iv_speakerOn);
        iv_speakerOff = view.findViewById(R.id.iv_speakerOff);
        tv_callDuration = view.findViewById(R.id.tv_callDuration);
        ll_searchingData = view.findViewById(R.id.ll_searchingData);
        ivMyImage = view.findViewById(R.id.ivMyImage);
        tv_myName = view.findViewById(R.id.tv_myName);
        ivOtherImage = view.findViewById(R.id.ivOtherImage);
        tv_otherUserName = view.findViewById(R.id.tv_otherUserName);

        sinchClientCreateion();

        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mMessageReceiver,
                new IntentFilter("Calling_notification"));

        iv_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callType.equals("incoming")) {
                    cl_callDurationData.setVisibility(View.VISIBLE);
                    cl_callData.setVisibility(View.GONE);
                    call.answer();
                    call.addCallListener(new SinchCallListener());
                }
            }
        });
        iv_callEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call.hangup();
                timeSwapBuff += timeInMilliseconds;
                customHandler.removeCallbacks(updateTimerThread);
                ll_callingData.setVisibility(View.GONE);
                ll_testData.setVisibility(View.VISIBLE);
            }
        });

        iv_callReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call.hangup();
                timeSwapBuff += timeInMilliseconds;
                customHandler.removeCallbacks(updateTimerThread);
                ll_testData.setVisibility(View.VISIBLE);
                ll_callingData.setVisibility(View.GONE);
            }
        });

        if (MainMenuActivity.user_pic.equals("")) {
            if (MainMenuActivity.sharedPreferences.getString(Variables.gender, "").equals("female")) {
                profile_image.setImageResource(R.drawable.female_img);
            } else if (MainMenuActivity.sharedPreferences.getString(Variables.gender, "").equals("male")) {
                profile_image.setImageResource(R.drawable.male_img);
            }
        } else {
            if (MainMenuActivity.sharedPreferences.getString(Variables.gender, "").equals("female")) {
                Picasso.with(context).
                        load(MainMenuActivity.user_pic)
                        .placeholder(R.drawable.female_img)
                        .into(profile_image);
            } else if (MainMenuActivity.sharedPreferences.getString(Variables.gender, "").equals("male")) {
                Picasso.with(context).
                        load(MainMenuActivity.user_pic)
                        .placeholder(R.drawable.male_img)
                        .into(profile_image);
            }
        }
        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!is_Api_running) {
                    is_Api_running = true;
                    GetPeople_nearby(false);
                }
            }
        });

        click_here.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TestFragment testFragment = new TestFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
                transaction.addToBackStack(null);
                transaction.replace(R.id.MainMenuFragment, testFragment).commit();
            }
        });

        iosDialog = new IOSDialog.Builder(context)
                .setCancelable(false)
                .setSpinnerClockwise(false)
                .setMessageContentGravity(Gravity.END)
                .build();

        GetPeople_nearby(false);

        card_viewstack = view.findViewById(R.id.card_viewstack);
        card_viewstack.setAdapter(adapter);
        card_viewstack.setCardEventListener(new CardStackView.CardEventListener() {
            @Override
            public void onCardDragging(float percentX, float percentY) {
            }

            @Override
            public void onCardSwiped(SwipeDirection direction) {

                // card swipe get the top user index for get the data in list
                int positon = card_viewstack.getTopIndex() - 1;


                if (positon < adapter.getCount()) {
                    final Nearby_User_Get_Set item = adapter.getItem(positon);


                    // if swipe left the we will call a fuction for update the value in firebase
                    if (direction.equals(SwipeDirection.Left)) {
                        updatedata_onLeftSwipe(item);
                    }

                    // if swipe Right the we will call a fuction for update the value in firebase

                    else if (direction.equals(SwipeDirection.Right)) {
                        updatedata_onrightSwipe(item);

                    }

                    // find if the swipes card is last or not
                    if (card_viewstack.getTopIndex() == adapter.getCount()) {
                        // if last then we will replace the view and show the ad
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                        }

                        ShowfindingView();
                    }
                }
            }

            @Override
            public void onCardReversed() {
                // card swipe get the top user index for get the data in list
                int positon = card_viewstack.getTopIndex();

                if (positon < adapter.getCount()) {
                    final Nearby_User_Get_Set item = adapter.getItem(positon);
                    updatedata_onreverse(item);
                }

                ShowUser_ListView();

            }

            @Override
            public void onCardMovedToOrigin() {

            }

            @Override
            public void onCardClicked(int index) {

            }
        });

        // on press detail btn we will open the detail of user
        detail_btn = view.findViewById(R.id.detail_btn);
        detail_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_user_detail();
            }
        });

        user_list_layout = view.findViewById(R.id.user_list_layout);
        find_nearby_User = view.findViewById(R.id.find_nearby_User);

        // intialize the bottom three btns
        init_bottom_view();
        is_view_load = true;


        Bundle bundle = getArguments();
        if (bundle!= null){
            if (bundle.getString("title").equals("Incoming Call")){
                tv_userName.setText(bundle.getString("name"));
                if (!bundle.getString("picture").equals("")){
                    Picasso.with(getActivity()).load(bundle.getString("picture")).placeholder(R.drawable.male_img).into(ivUserImage);
                }
                cl_callDurationData.setVisibility(View.GONE);
                cl_callData.setVisibility(View.VISIBLE);
                ll_callingData.setVisibility(View.VISIBLE);
                ll_testData.setVisibility(View.GONE);

                animation = AnimationUtils.loadAnimation(getApplicationContext(),
                        R.anim.bounce_animation);
                animation.setDuration(400);
                animation.setRepeatCount(10);
                iv_call.startAnimation(animation);

                animation1 = AnimationUtils.loadAnimation(getApplicationContext(),
                        R.anim.bounce_animation);
                animation1.setDuration(4000);
                animation1.setRepeatCount(10);
                iv_callReject.startAnimation(animation1);
            }
        }
        return view;
    }


    // when we swipe left , right or reverse then this method is call and update the value in firebase database
    public void updatedata_onLeftSwipe(final Nearby_User_Get_Set item) {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);

        rootref.child("Match").child(item.getFb_id()).child(MainMenuActivity.user_id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getName());
                    mymap.put("effect", "true");


                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", MainMenuActivity.user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");
                    mymap.put("type", "dislike");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");
                    othermap.put("type", "dislike");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", MainMenuActivity.user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).setValue(mymap);
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        SendPushNotification(item.fb_id, MainMenuActivity.user_name + " has Dislike your Profile");

    }

    public void updatedata_onrightSwipe(final Nearby_User_Get_Set item) {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("hh");
        final String formattedDate = df.format(c);


        Query query = rootref.child("Match").child(item.getFb_id()).child(MainMenuActivity.user_id);
        query.keepSynced(true);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() || item.getSwipe().equals("like")) {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "true");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "true");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", MainMenuActivity.user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).updateChildren(othermap);

                } else {
                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");
                    mymap.put("type", "like");
                    mymap.put("status", "0");
                    mymap.put("time", formattedDate);
                    mymap.put("name", item.getName());
                    mymap.put("effect", "true");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");
                    othermap.put("type", "like");
                    othermap.put("status", "0");
                    othermap.put("time", formattedDate);
                    othermap.put("name", MainMenuActivity.user_name);
                    othermap.put("effect", "false");

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).setValue(mymap);
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).setValue(othermap);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        SendPushNotification(item.fb_id, MainMenuActivity.user_name + " has Likes your Profile");
        Match_Get_Set match_get_set = new Match_Get_Set();
        match_get_set.setU_id(item.getFb_id());
        match_get_set.setUsername(item.getName());
        match_get_set.setPicture(item.getImagesurl().get(0));
        openMatch(match_get_set);
//        if (item.getSwipe().equals("like")) {
//            Match_Get_Set match_get_set = new Match_Get_Set();
//            match_get_set.setU_id(item.getFb_id());
//            match_get_set.setUsername(item.getName());
//            match_get_set.setPicture(item.getImagesurl().get(0));
//            openMatch(match_get_set);
//        }
    }

    public void updatedata_onreverse(final Nearby_User_Get_Set item) {

        Query query = rootref.child("Match").child(item.getFb_id()).child(MainMenuActivity.user_id);
        query.keepSynced(true);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("match").getValue().equals("true")) {

                    Map mymap = new HashMap<>();
                    mymap.put("match", "false");

                    Map othermap = new HashMap<>();
                    othermap.put("match", "false");

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).updateChildren(mymap);
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).updateChildren(othermap);

                } else {

                    rootref.child("Match").child(MainMenuActivity.user_id + "/" + item.getFb_id()).removeValue();
                    rootref.child("Match").child(item.getFb_id() + "/" + MainMenuActivity.user_id).removeValue();

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    // when ever a user go to the main center view then we call a api of nearby
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if ((isVisibleToUser && Variables.is_reload_users) && is_view_load) {
            if (!is_Api_running) {
                is_Api_running = true;
                Variables.is_reload_users = false;
                GetPeople_nearby(false);
            }
        }
    }

    // when all the card is swiped then this mehtod will call and replace the view and show the ad
    public void ShowfindingView() {
        Variables.is_reload_users = true;
        user_list_layout.setVisibility(View.GONE);
        find_nearby_User.setVisibility(View.VISIBLE);

        final PulsatorLayout pulsator = (PulsatorLayout) view.findViewById(R.id.pulsator);
        pulsator.start();

        view.findViewById(R.id.change_setting_btn).setOnClickListener(this);
        view.findViewById(R.id.finding_refresh_btn).setOnClickListener(this);

    }

    public void ShowUser_ListView() {
        user_list_layout.setVisibility(View.VISIBLE);
        find_nearby_User.setVisibility(View.GONE);
    }

    // this method will intializae the inertial add will will show when user swipe all the users
    private InterstitialAd mInterstitialAd;

    @Override
    public void onResume() {
        super.onResume();
        MobileAds.initialize(context, "ca-app-pub-3940256099942544~3347511713");

        //code for intertial add
        mInterstitialAd = new InterstitialAd(context);

        //here we will get the add id keep in mind above id is app id and below Id is add Id
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.my_Interstitial_Add));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });

    }

    // intilize the bottom three buttons
    public void init_bottom_view() {
        refresh_btn = view.findViewById(R.id.refresh_btn);
        cross_btn = view.findViewById(R.id.cross_btn);
        heart_btn = view.findViewById(R.id.heart_btn);

        refresh_btn.setOnClickListener(this);
        cross_btn.setOnClickListener(this);
        heart_btn.setOnClickListener(this);
    }

    /// / all the action that will performe the bottom 3 buttons
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.cross_btn:
                Clearbackstack();
                swipeLeft();
                break;

            case R.id.heart_btn:
                Clearbackstack();
                swipeRight();
                break;


            case R.id.refresh_btn:
                if (MainMenuActivity.purduct_purchase) {
                    card_viewstack.reverse();
                } else
                    open_subscription_view();
                break;

            case R.id.finding_refresh_btn:
                if (!MainMenuActivity.purduct_purchase) {
                    card_viewstack.reverse();
                } else
                    open_subscription_view();
                break;

            case R.id.change_setting_btn:
                open_discoverysetting_dialog();
                break;

        }
    }

    // below two method will automatically swipe the card
    public void swipeLeft() {
        View target = card_viewstack.getTopView();
        View targetOverlay = card_viewstack.getTopView().getOverlayContainer();

        ValueAnimator rotation = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("rotation", -10f));
        rotation.setDuration(200);
        ValueAnimator translateX = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationX", 0f, -2000f));
        ValueAnimator translateY = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationY", 0f, 500f));
        translateX.setStartDelay(400);
        translateY.setStartDelay(400);
        translateX.setDuration(500);
        translateY.setDuration(500);
        AnimatorSet cardAnimationSet = new AnimatorSet();
        cardAnimationSet.playTogether(rotation, translateX, translateY);

        ObjectAnimator overlayAnimator = ObjectAnimator.ofFloat(targetOverlay, "alpha", 0f, 1f);
        overlayAnimator.setDuration(200);
        AnimatorSet overlayAnimationSet = new AnimatorSet();
        overlayAnimationSet.playTogether(overlayAnimator);

        card_viewstack.swipe(SwipeDirection.Left, cardAnimationSet, overlayAnimationSet);
    }

    public void swipeRight() {


        View target = card_viewstack.getTopView();
        View targetOverlay = card_viewstack.getTopView().getOverlayContainer();

        ValueAnimator rotation = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("rotation", 10f));
        rotation.setDuration(200);
        ValueAnimator translateX = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationX", 0f, 2000f));
        ValueAnimator translateY = ObjectAnimator.ofPropertyValuesHolder(
                target, PropertyValuesHolder.ofFloat("translationY", 0f, 500f));
        translateX.setStartDelay(400);
        translateY.setStartDelay(400);
        translateX.setDuration(500);
        translateY.setDuration(500);
        AnimatorSet cardAnimationSet = new AnimatorSet();
        cardAnimationSet.playTogether(rotation, translateX, translateY);

        ObjectAnimator overlayAnimator = ObjectAnimator.ofFloat(targetOverlay, "alpha", 0f, 1f);
        overlayAnimator.setDuration(200);
        AnimatorSet overlayAnimationSet = new AnimatorSet();
        overlayAnimationSet.playTogether(overlayAnimator);

        card_viewstack.swipe(SwipeDirection.Right, cardAnimationSet, overlayAnimationSet);
    }

    // if any fagment is open then it will closs the fragment
    public void Clearbackstack() {
        FragmentManager fm = getActivity().getSupportFragmentManager();
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }

    }
    // below two method will get all the  new user that is nearby of us  and parse the data in dataset
    // in that case which has a name of Nearby get set
    private void GetPeople_nearby(final boolean is_show_loader) {

        if (is_show_loader) {
            iosDialog.show();
        }

        String latlong = "";
        if (MainMenuActivity.sharedPreferences.getBoolean(Variables.is_seleted_location_selected, false)) {
            latlong = MainMenuActivity.sharedPreferences.getString(Variables.seleted_Lat, "33.738045") + ", " + MainMenuActivity.sharedPreferences.getString(Variables.selected_Lon, "73.084488");
        } else {
            latlong = MainMenuActivity.sharedPreferences.getString(Variables.current_Lat, "33.738045") + ", " + MainMenuActivity.sharedPreferences.getString(Variables.current_Lon, "73.084488");
        }


        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", MainMenuActivity.user_id);
            parameters.put("lat_long", latlong);
            parameters.put("gender", MainMenuActivity.sharedPreferences.getString(Variables.show_me, "all"));
            parameters.put("age_range", "" + MainMenuActivity.sharedPreferences.getInt(Variables.max_age, Variables.default_age));
            parameters.put("distance", "" + MainMenuActivity.sharedPreferences.getInt(Variables.max_distance, Variables.default_distance));
            parameters.put("version", Variables.versionname);
            parameters.put("device_token", MainMenuActivity.token);
            parameters.put("device", context.getResources().getString(R.string.device));
//            parameters.put("ethnicity",MainMenuActivity.sharedPreferences.getString(Variables.ethnicity,"all"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d("resp", parameters.toString());

        RequestQueue rq = Volley.newRequestQueue(context);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, Variables.userNearByMe, parameters, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (is_show_loader) {
                            iosDialog.cancel();
                        }
                        String respo = response.toString();
                        Log.d("responce", respo);
                        Parse_user_info(respo);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (is_show_loader) {
                            iosDialog.cancel();
                        }
                        is_Api_running = false;
                        Log.d("respoeee", error.toString());
                    }
                });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        rq.getCache().clear();
        rq.add(jsonObjectRequest);
    }

    String block = "0";

    public void Parse_user_info(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                adapter.clear();
                JSONArray msg = jsonObject.getJSONArray("msg");
                Log.e("response_data", msg.toString());
                for (int i = 0; i < msg.length(); i++) {
                    JSONObject userdata = msg.getJSONObject(i);
                    Nearby_User_Get_Set item = new Nearby_User_Get_Set();
                    item.setFb_id(userdata.optString("fb_id"));
                    item.setId(userdata.optString("id"));
                    item.setFirst_name(userdata.optString("first_name"));
                    item.setLast_name(userdata.optString("last_name"));
                    item.setName(userdata.optString("first_name") + " " + userdata.optString("last_name"));
                    item.setJob_title(userdata.optString("job_title"));
                    item.setCompany(userdata.optString("company"));
                    item.setSchool(userdata.optString("school"));
                    item.setBirthday(userdata.optString("birthday"));
                    item.setAbout(userdata.optString("about_me"));
                    item.setLocation(userdata.optString("distance"));
                    item.setGender(userdata.optString("gender"));
                    item.setSwipe(userdata.optString("swipe"));
                    item.setTestResult(userdata.optString("test_result1"));

                    block = userdata.optString("block");
                    ArrayList<String> images = new ArrayList<>();
                    images.add(userdata.optString("image1"));
                    if (!userdata.optString("image2").equals(""))
                        images.add(userdata.optString("image2"));

                    if (!userdata.optString("image3").equals(""))
                        images.add(userdata.optString("image3"));

                    if (!userdata.optString("image4").equals(""))
                        images.add(userdata.optString("image4"));

                    if (!userdata.optString("image5").equals(""))
                        images.add(userdata.optString("image5"));

                    if (!userdata.optString("image6").equals(""))
                        images.add(userdata.optString("image6"));

                    item.setImagesurl(images);
                    usersList.add(item);
                    adapter.add(item);
                }
                setUserData(usersList);

                if (!(msg.length() > 0)) {
                    ShowfindingView();
                } else {
                    ShowUser_ListView();
                }

                is_Api_running = false;
                adapter.notifyDataSetChanged();

                if (block.equals("1")) {
                    // on press logout btn we will chat the local value and move the user to login screen
                    MainMenuActivity.sharedPreferences.edit().putBoolean(Variables.islogin, false).commit();
                    startActivity(new Intent(getActivity(), Login_A.class));
                    getActivity().overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
                    getActivity().finish();
                }
            }
        } catch (JSONException e) {

            e.printStackTrace();
        }


    }

    // this mehtod will show the view which will show the more detail about the user
    public void open_user_detail() {

        User_detail_F user_detail_f = new User_detail_F();

        Nearby_User_Get_Set item = adapter.getItem(card_viewstack.getTopIndex());
        Bundle args = new Bundle();
        args.putSerializable("data", item);
        user_detail_f.setArguments(args);

        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.MainMenuFragment, user_detail_f)
                .addToBackStack(null)
                .commit();

    }

    // when user will click the refresh btn  then this view will be open for subscribe it in our app
    public void open_subscription_view() {
        InApp_Subscription_A inApp_subscription_a = new InApp_Subscription_A();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.MainMenuFragment, inApp_subscription_a)
                .addToBackStack(null)
                .commit();
    }

    private void open_discoverysetting_dialog() {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.item_discovery_setting_dialog);
        dialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.d_top_bottom_border_line));

        TextView cancel_btn = dialog.findViewById(R.id.cancel_btn);
        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

        TextView update_btn = dialog.findViewById(R.id.update_btn);
        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetPeople_nearby(true);
                dialog.cancel();
            }
        });


        SignSeekBar distance_bar = dialog.findViewById(R.id.distance_bar);
        final TextView distance_txt = dialog.findViewById(R.id.distance_txt);
        distance_bar.setProgress(MainMenuActivity.sharedPreferences.getInt(Variables.max_distance, Variables.default_distance));
        distance_txt.setText(MainMenuActivity.sharedPreferences.getInt(Variables.max_distance, Variables.default_distance) + " miles");
        distance_bar.setOnProgressChangedListener(new SignSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser) {
                distance_txt.setText(progress + " miles");
            }

            @Override
            public void getProgressOnActionUp(SignSeekBar signSeekBar, int progress, float progressFloat) {
                Variables.is_reload_users = true;
                MainMenuActivity.sharedPreferences.edit().putInt(Variables.max_distance, progress).commit();
            }

            @Override
            public void getProgressOnFinally(SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });


        // this is the age seek bar. when we change the progress of seek bar it will be locally save
        SignSeekBar age_seekbar = dialog.findViewById(R.id.age_seekbar);
        final TextView age_range_txt = dialog.findViewById(R.id.age_range_txt);
        age_seekbar.setProgress(MainMenuActivity.sharedPreferences.getInt(Variables.max_age, Variables.default_age));
        age_range_txt.setText(MainMenuActivity.sharedPreferences.getInt(Variables.max_age, Variables.default_age) + " Years");
        age_seekbar.setOnProgressChangedListener(new SignSeekBar.OnProgressChangedListener() {
            @Override
            public void onProgressChanged(SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser) {
                age_range_txt.setText(progress + " Years");
            }

            @Override
            public void getProgressOnActionUp(SignSeekBar signSeekBar, int progress, float progressFloat) {
                Variables.is_reload_users = true;
                MainMenuActivity.sharedPreferences.edit().putInt(Variables.max_age, progress).commit();
            }

            @Override
            public void getProgressOnFinally(SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser) {

            }
        });

        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int displayWidth = displayMetrics.widthPixels;

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();

        layoutParams.copyFrom(dialog.getWindow().getAttributes());

        int dialogWindowWidth = (int) (displayWidth * 0.9f);
        layoutParams.width = dialogWindowWidth;
        dialog.getWindow().setAttributes(layoutParams);
    }

    // when a match is build between user then this method is call and open the view if match screen
    public void openMatch(Match_Get_Set item) {
        Match_F match_f = new Match_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        Bundle args = new Bundle();
        args.putSerializable("data", item);
        match_f.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.MainMenuFragment, match_f).commit();
    }

    // when this screen open it will send the notification to other user that
    // both are like the each other and match will build between the users
    public void SendPushNotification(final String receverid, final String message) {
        rootref.child("Users").child(receverid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    String token = dataSnapshot.child("token").getValue().toString();
                    JSONObject notimap = new JSONObject();
                    try {
                        notimap.put("title", "Incoming Call");
                        notimap.put("message", message);
                        notimap.put("icon", MainMenuActivity.user_pic);
                        notimap.put("tokon", token);
                        notimap.put("senderid", MainMenuActivity.user_id);
                        notimap.put("receiverid", receverid);
                        notimap.put("action_type", "Like_Dislike");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Functions.Call_api_Send_Notification(getActivity(), notimap);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void setUserData(final ArrayList<Nearby_User_Get_Set> usersList) {
        Log.e("data", usersList.size() + "  ");
        user_list_layout.setVisibility(View.GONE);
        find_nearby_User.setVisibility(View.GONE);
        discreteScrollView.setOrientation(DSVOrientation.HORIZONTAL);
        discreteScrollView.addOnItemChangedListener(this);
        usersAdapter_new = InfiniteScrollAdapter.wrap(new UsersAdapter_New(usersList, this));
        discreteScrollView.setAdapter(usersAdapter_new);
        discreteScrollView.setItemTransitionTimeMillis(150);
        discreteScrollView.setItemTransformer(new ScaleTransformer.Builder()
                .setMinScale(0.8f)
                .build());

        discreteScrollView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        discreteScrollView.addOnItemChangedListener(new DiscreteScrollView.OnItemChangedListener<RecyclerView.ViewHolder>() {
            @Override
            public void onCurrentItemChanged(@Nullable RecyclerView.ViewHolder viewHolder, int position) {
                Log.e("current_item_pos",discreteScrollView.getCurrentItem()+"   sdd ");
//                tv_userName.setText(usersList.get(position).name);
//                if (!usersList.get(position).getImagesurl().get(0).equals("")) {
//                    if (usersList.get(position).getGender().equals("male"))
//                        Picasso.with(context).load(usersList.get(position).imagesurl.get(0)).placeholder(R.drawable.male_img).into(ivUserImage);
//                    else
//                        Picasso.with(context).load(usersList.get(position).imagesurl.get(0)).placeholder(R.drawable.female_img).into(ivUserImage);
//                }
//                else{
//                 if (usersList.get(position).getGender().equals("male"))
//                     ivUserImage.setImageResource(R.drawable.male_img);
//                     else
//                     ivUserImage.setImageResource(R.drawable.female_img);
//                }
//                receiverName = usersList.get(position).first_name;
            }
        });
//        onItemChanged(usersList.get(0));
    }

    @Override
    public void onCurrentItemChanged(@Nullable RecyclerView.ViewHolder viewHolder, int adapterPosition) {
    }

    private void onItemChanged(Nearby_User_Get_Set item) {
//        currentItemName.setText(item.getName());
//        currentItemPrice.setText(item.getPrice());
//        changeRateButtonState(item);
    }

    @Override
    public void onItemCLick(int position, String type) {
        if (type.equals("call")) {
            callType ="outgoing_call";
            tv_userName.setText(usersList.get(position).name);
            if (!usersList.get(position).getImagesurl().get(0).equals("")) {
                if (usersList.get(position).getGender().equals("male"))
                    Picasso.with(context).load(usersList.get(position).imagesurl.get(0)).placeholder(R.drawable.male_img).into(ivUserImage);
                else
                    Picasso.with(context).load(usersList.get(position).imagesurl.get(0)).placeholder(R.drawable.female_img).into(ivUserImage);
            }
            else{
                if (usersList.get(position).getGender().equals("male"))
                    ivUserImage.setImageResource(R.drawable.male_img);
                else
                    ivUserImage.setImageResource(R.drawable.female_img);
            }
            receiverName = usersList.get(position).first_name;
            ll_callingData.setVisibility(View.VISIBLE);
            cl_callData.setVisibility(View.VISIBLE);
            cl_callDurationData.setVisibility(View.GONE);
            ll_testData.setVisibility(View.GONE);
            ll_searchingData.setVisibility(View.GONE);

            if (call == null) {
                call = sinchClient.getCallClient().callUser(receiverName);
                call.addCallListener(new SinchCallListener());
                SendPushNotification(usersList.get(position).getFb_id(),MainMenuActivity.sharedPreferences.getString(Variables.f_name,"")+" "+
                        MainMenuActivity.sharedPreferences.getString(Variables.l_name,"")+" is trying to call you.");
            } else {
                call.hangup();
            }
            cl_callData.setVisibility(View.GONE);
            cl_callDurationData.setVisibility(View.VISIBLE);
        } else if (type.equals("chat")) {
            callChatScreen(position);
        } else if (type.equals("image")) {
            Profile_Details_F profile_details_f = new Profile_Details_F();
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
            Bundle args = new Bundle();
            args.putString("user_id", usersList.get(position).getFb_id());
            args.putString("from", "chat");
            profile_details_f.setArguments(args);
            transaction.addToBackStack(null);
            transaction.replace(R.id.MainMenuFragment, profile_details_f).commit();
        } else {
            updatedata_onrightSwipe(usersList.get(position));
        }
    }

    private void callChatScreen(int position) {
        Chat_Activity chat_activity = new Chat_Activity();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("Sender_Id", MainMenuActivity.user_id);
        args.putString("Receiver_Id", usersList.get(position).getId());
        args.putString("picture", usersList.get(position).getImagesurl().get(0));
        args.putString("name", usersList.get(position).getName());
        args.putBoolean("is_match_exits", true);
        chat_activity.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.MainMenuFragment, chat_activity).commit();
    }


    public void sinchClientCreateion() {
        sinchClient = Sinch.getSinchClientBuilder()
                .context(getActivity())
                .userId(MainMenuActivity.sharedPreferences.getString(Variables.f_name, ""))
                .applicationKey(APP_KEY)
                .applicationSecret(APP_SECRET)
                .environmentHost(ENVIRONMENT)
                .build();

        sinchClient.setSupportCalling(true);
        sinchClient.startListeningOnActiveConnection();
        sinchClient.start();

        sinchClient.getCallClient().addCallClientListener(new SinchCallClientListener());

        call = sinchClient.getCallClient().getCall("Developer");
        if (call != null){
            Log.e("call_available","uyes");
        }else{
            Log.e("call_available","no");
        }
    }

    private class SinchCallListener implements CallListener {
        @Override
        public void onCallEnded(Call endedCall) {
            Log.e("sinch_calling", "call_ended");
            call = null;
            ll_testData.setVisibility(View.VISIBLE);
            ll_callingData.setVisibility(View.GONE);
            SinchError a = endedCall.getDetails().getError();
            getActivity().setVolumeControlStream(AudioManager.USE_DEFAULT_STREAM_TYPE);
        }

        @Override
        public void onCallEstablished(Call establishedCall) {
            Log.e("sinch_calling", "call_established");
            cl_callDurationData.setVisibility(View.VISIBLE);
            cl_callData.setVisibility(View.GONE);
            startTime = SystemClock.uptimeMillis();
            customHandler.postDelayed(updateTimerThread, 0);
            getActivity().setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
        }

        @Override
        public void onCallProgressing(Call progressingCall) {
            Log.e("sinch_calling", "call_progress");
        }

        @Override
        public void onShouldSendPushNotification(Call call, List<PushPair> pushPairs) {
            sinchClient.setSupportManagedPush(true);
            sinchClient.start();
        }
    }

    private class SinchCallClientListener implements CallClientListener {
        @Override
        public void onIncomingCall(CallClient callClient, Call incomingCall) {
            call = incomingCall;
//            Toast.makeText(getActivity(), "incoming call", Toast.LENGTH_SHORT).show();
            callType = "incoming";
            cl_callDurationData.setVisibility(View.GONE);
            cl_callData.setVisibility(View.VISIBLE);
            ll_callingData.setVisibility(View.VISIBLE);
            ll_testData.setVisibility(View.GONE);

            animation = AnimationUtils.loadAnimation(getApplicationContext(),
                    R.anim.bounce_animation);
            animation.setDuration(4000);
            animation.setRepeatCount(10);
            iv_call.startAnimation(animation);

            animation1 = AnimationUtils.loadAnimation(getApplicationContext(),
                    R.anim.bounce_animation);
            animation1.setDuration(4000);
            animation1.setRepeatCount(10);
            iv_callReject.startAnimation(animation1);
        }
    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("notificationl", "yes received");
        }
    };

    private Runnable updateTimerThread = new Runnable() {
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            updatedTime = timeSwapBuff + timeInMilliseconds;
            int secs = (int) (updatedTime / 1000);
            int mins = secs / 60;
            secs = secs % 60;
            int milliseconds = (int) (updatedTime % 1000);
            if (mins<10) {
                tv_callDuration.setText("0" + mins + ":"
                        + String.format("%02d", secs));
            }else{
                tv_callDuration.setText("" + mins + ":"
                        + String.format("%02d", secs));
            }
            customHandler.postDelayed(this, 0);
        }
    };

}