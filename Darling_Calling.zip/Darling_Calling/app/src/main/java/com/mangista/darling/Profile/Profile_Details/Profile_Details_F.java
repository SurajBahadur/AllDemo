package com.mangista.darling.Profile.Profile_Details;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;
import com.mangista.darling.Chat.Chat_Activity;
import com.mangista.darling.CodeClasses.Variables;
import com.mangista.darling.Main_Menu.MainMenuActivity;
import com.mangista.darling.Profile.EditProfile.EditProfile_F;
import com.mangista.darling.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class Profile_Details_F extends Fragment {
    View view;
    Context context;
    ImageButton move_downbtn, edit_btn;
    RelativeLayout username_layout;
    ScrollView scrollView;
    SliderLayout sliderLayout;
    PagerIndicator pagerIndicator;
    ArrayList<String> images_list;
    TextView user_name_txt, user_jobtitle_txt, user_school_txt, user_birthday_txt, user_location_text,
            user_gender_txt, user_aboutme_txt, reportUserText, tv_percent, match_text;
    LinearLayout job_layout, school_layout, birthday_layout, gender_layout, report_layout;
    String user_id;
    ImageView iv_call, iv_message;
    RelativeLayout ll_buttons;
    String picturesData="",name="";

    public Profile_Details_F() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_profile_details, container, false);
        context = getContext();

        scrollView = view.findViewById(R.id.scrollView);
        username_layout = view.findViewById(R.id.username_layout);
        user_location_text = view.findViewById(R.id.user_location_text);

        move_downbtn = view.findViewById(R.id.move_downbtn);
        move_downbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        edit_btn = view.findViewById(R.id.edit_btn);
        edit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getActivity().onBackPressed();
                Editprofile();
            }
        });

        user_name_txt = view.findViewById(R.id.user_name_txt);
        user_jobtitle_txt = view.findViewById(R.id.user_jobtitle_txt);
        user_school_txt = view.findViewById(R.id.user_school_txt);
        user_birthday_txt = view.findViewById(R.id.user_birthday_txt);
        user_gender_txt = view.findViewById(R.id.user_gender_txt);
        user_aboutme_txt = view.findViewById(R.id.user_about_txt);
        job_layout = view.findViewById(R.id.job_layout);
        school_layout = view.findViewById(R.id.school_layout);
        birthday_layout = view.findViewById(R.id.birthday_layout);
        gender_layout = view.findViewById(R.id.gender_layout);
        reportUserText = view.findViewById(R.id.reportUserText);
        report_layout = view.findViewById(R.id.report_layout);
        ll_buttons = view.findViewById(R.id.ll_buttons);
        iv_call = view.findViewById(R.id.iv_call);
        tv_percent = view.findViewById(R.id.tv_percent);
        iv_message = view.findViewById(R.id.iv_message);
        match_text = view.findViewById(R.id.match_text);

        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.getString("from").equals("chat")) {
                edit_btn.setVisibility(View.GONE);
                ll_buttons.setVisibility(View.VISIBLE);
                report_layout.setVisibility(View.VISIBLE);
                match_text.setVisibility(View.VISIBLE);
                user_id = bundle.getString("user_id");
            } else {
                ll_buttons.setVisibility(View.GONE);
                report_layout.setVisibility(View.GONE);
                match_text.setVisibility(View.GONE);
                user_id = MainMenuActivity.user_id;
            }
        } else {
            user_id = MainMenuActivity.user_id;
            ll_buttons.setVisibility(View.GONE);
            report_layout.setVisibility(View.GONE);
            match_text.setVisibility(View.GONE);
        }


        images_list = new ArrayList<>();
        sliderLayout = view.findViewById(R.id.slider);
        pagerIndicator = view.findViewById(R.id.custom_indicator);
        sliderLayout.setVisibility(View.INVISIBLE);

        YoYo.with(Techniques.BounceInDown)
                .duration(800)
                .playOn(move_downbtn);

        Get_User_info();


        iv_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callChatScreen();
            }
        });
        return view;
    }

    private void callChatScreen() {
        Chat_Activity chat_activity = new Chat_Activity();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.in_from_bottom, R.anim.out_to_top, R.anim.in_from_top, R.anim.out_from_bottom);
        Bundle args = new Bundle();
        args.putString("Sender_Id", MainMenuActivity.user_id);
        args.putString("Receiver_Id", user_id);
        args.putString("picture",picturesData);
        args.putString("name",name );
        args.putBoolean("is_match_exits", true);
        chat_activity.setArguments(args);
        transaction.addToBackStack(null);
        transaction.replace(R.id.MainMenuFragment, chat_activity).commit();
    }


    // below two method is used get the user pictures and about text from our server
    private void Get_User_info() {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", user_id);
            parameters.put("u_id", MainMenuActivity.user_id);
            Log.e("getUser_info", user_id + "   " + MainMenuActivity.user_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue rq = Volley.newRequestQueue(context);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, Variables.getUserInfo, parameters, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String respo = response.toString();
                        Log.d("responce", respo);
                        Parse_user_info(respo);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Log.d("respo", error.toString());
                    }
                });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        rq.getCache().clear();
        rq.add(jsonObjectRequest);
    }


    public void Parse_user_info(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                JSONArray msg = jsonObject.getJSONArray("msg");
                JSONObject userdata = msg.getJSONObject(0);

                images_list.clear();
                images_list.add(userdata.optString("image1"));
                images_list.add(userdata.optString("image2"));
                images_list.add(userdata.optString("image3"));
                images_list.add(userdata.optString("image4"));
                images_list.add(userdata.optString("image5"));
                images_list.add(userdata.optString("image6"));

                picturesData = userdata.optString("image1");
                name = userdata.optString("first_name")+" "+userdata.optString("last_name");

                user_name_txt.setText(userdata.optString("first_name") + " " + userdata.optString("last_name") + " ," + userdata.optString("age"));

                String user_jobtitle = userdata.optString("job_title");
                String user_company = userdata.optString("company");
                String user_school = userdata.optString("school");
                String user_birthday = userdata.optString("birthday");
                String user_gender = userdata.optString("gender");

                if (user_jobtitle.equals("") & !user_company.equals("")) {
                    user_jobtitle_txt.setText(user_company);
                } else if (user_company.equals("") && !user_jobtitle.equals("")) {
                    user_jobtitle_txt.setText(user_jobtitle);
                } else if (user_company.equals("") && user_jobtitle.equals("")) {
                    job_layout.setVisibility(View.GONE);
                } else {
                    user_jobtitle_txt.setText(user_jobtitle + " at " + user_company);
                }


                user_school_txt.setText(userdata.optString("school"));
                user_birthday_txt.setText(userdata.optString("birthday"));
                user_gender_txt.setText(userdata.optString("gender"));
                user_aboutme_txt.setText(userdata.optString("about_me"));
                user_location_text.setText(userdata.optString("distance"));
                reportUserText.setText(getActivity().getResources().getString(R.string.report) + " " + userdata.optString("first_name"));

                if (userdata.optString("test_result_ratio").equals("")){
                    tv_percent.setBackgroundResource(R.drawable.ic_no_match);
                } else if (userdata.optString("test_result_ratio").equals("11")){
                    tv_percent.setBackgroundResource(R.drawable.ic_11_match);
                }else if (userdata.optString("test_result_ratio").equals("23")){
                    tv_percent.setBackgroundResource(R.drawable.ic_23_match);
                }else if (userdata.optString("test_result_ratio").equals("65")){
                    tv_percent.setBackgroundResource(R.drawable.ic_65_match);
                }else if (userdata.optString("test_result_ratio").equals("84")){
                    tv_percent.setBackgroundResource(R.drawable.ic_84_match);
                }else if (userdata.optString("test_result_ratio").equals("92")){
                    tv_percent.setBackgroundResource(R.drawable.ic_92_match);
                }else if (userdata.optString("test_result_ratio").equals("98")){
                    tv_percent.setBackgroundResource(R.drawable.ic_98_match);
                }else{
                    tv_percent.setBackgroundResource(R.drawable.ic_no_match);
                }
                

                if (user_school.equals("")) {
                    school_layout.setVisibility(View.GONE);
                }
                if (user_birthday.equals("")) {
                    birthday_layout.setVisibility(View.GONE);
                }
                if (user_gender.equals("")) {
                    gender_layout.setVisibility(View.GONE);
                }

                fill_data();
            }
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }


    // this method will set and show the pictures slider
    public void fill_data() {
        sliderLayout.setCustomIndicator(pagerIndicator);
        sliderLayout.stopAutoCycle();

        for (int i = 0; i < images_list.size(); i++) {
            if (!images_list.get(i).equals("")) {
                DefaultSliderView defaultSliderView = new DefaultSliderView(context);
                defaultSliderView
                        .image(images_list.get(i))
                        .setScaleType(BaseSliderView.ScaleType.Fit);
                defaultSliderView.bundle(new Bundle());
                sliderLayout.addSlider(defaultSliderView);
            }
        }
        sliderLayout.setVisibility(View.VISIBLE);
    }


    // open the view of Edit profile where 6 pic is visible
    public void Editprofile() {
        EditProfile_F editProfile_f = new EditProfile_F();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.addToBackStack(null);
        transaction.replace(R.id.MainMenuFragment, editProfile_f).commit();
    }
}
