package com.mangista.darling.Users;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;
import com.mangista.darling.R;
import com.mangista.darling.callbacks.UserItemClicked;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class UsersAdapter_New extends RecyclerView.Adapter<UsersAdapter_New.ViewHolder> {

    private List<Nearby_User_Get_Set> data;
    UserItemClicked userItemClicked;

    public UsersAdapter_New(List<Nearby_User_Get_Set> data, UserItemClicked userItemClicked) {
        this.data = data;
        this.userItemClicked= userItemClicked;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.item_users_cards_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        if (data.get(position).getImagesurl().size()>0) {
         if (!data.get(position).getImagesurl().get(0).equals(""))
             Glide.with(holder.itemView.getContext())
                    .load(data.get(position).getImagesurl().get(0))
                    .into(holder.image1);
        }

        holder.tv_name.setText(data.get(position).getName());
        holder.tv_profession.setText(data.get(position).getLocation());
        holder.userAge.setText(", "+data.get(position).getBirthday());
        holder.iv_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userItemClicked.onItemCLick(position,"call");
            }
        });


        holder.iv_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userItemClicked.onItemCLick(position,"chat");
            }
        });

        holder.image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userItemClicked.onItemCLick(position,"image");
            }
        });


        if (data.get(position).getTestResult()!= null){
            if (data.get(position).getTestResult().equals("11")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_11_match);
            }else if (data.get(position).getTestResult().equals("23")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_23_match);
            }else if (data.get(position).getTestResult().equals("65")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_65_match);
            }else if (data.get(position).getTestResult().equals("84")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_84_match);
            }else if (data.get(position).getTestResult().equals("92")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_92_match);
            }else if (data.get(position).getTestResult().equals("98")){
                holder.tv_percent.setBackgroundResource(R.drawable.ic_98_match);
            }else{
                holder.tv_percent.setBackgroundResource(R.drawable.ic_no_match);
            }
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private RoundedImageView image;
        private CircleImageView image1;
        private TextView  tv_name,tv_profession,userAge,tv_percent;
        ImageView iv_call,iv_message;

        public ViewHolder(View itemView) {
            super(itemView);
            image = (RoundedImageView) itemView.findViewById(R.id.image);
            image1 = (CircleImageView) itemView.findViewById(R.id.image1);
            tv_name = (TextView) itemView.findViewById(R.id.username);
            userAge = (TextView) itemView.findViewById(R.id.userAge);
            tv_profession = (TextView) itemView.findViewById(R.id.profession);
            tv_percent = (TextView) itemView.findViewById(R.id.tv_percent);
            iv_call = (ImageView) itemView.findViewById(R.id.iv_call);
            iv_message = (ImageView) itemView.findViewById(R.id.iv_message);
        }
    }
}