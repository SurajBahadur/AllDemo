package com.mangista.darling.callbacks;

public interface UserItemClicked {
    public void onItemCLick(int position, String type);
}
