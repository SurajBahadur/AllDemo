package com.mangista.darling;

import android.app.Application;

import com.mangista.darling.Users.DiscreteScrollViewOptions;

public class App extends Application {

    private static App instance;

    public static App getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        DiscreteScrollViewOptions.init(this);
    }
}