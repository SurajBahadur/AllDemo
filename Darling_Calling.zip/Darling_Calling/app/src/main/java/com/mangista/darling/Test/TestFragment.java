package com.mangista.darling.Test;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.gmail.samehadar.iosdialog.IOSDialog;
import com.mangista.darling.Accounts.Get_User_Info_A;
import com.mangista.darling.CodeClasses.Variables;
import com.mangista.darling.Main_Menu.MainMenuActivity;
import com.mangista.darling.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TestFragment extends Fragment {
    View view;
    Context context;
    ImageView backButton;
    WebView webView;
    String url;
    String TAG = "WebViewTest";
    ProgressDialog progressBar;
    int loaded = 0;
    IOSDialog iosDialog;
    String resultValue = "";

    @SuppressLint("JavascriptInterface")
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_test, container, false);
        context = getContext();

        backButton = view.findViewById(R.id.iv_back);
        webView = view.findViewById(R.id.webView);
        url = "http://www.tiktalkapp.com/test";

        iosDialog = new IOSDialog.Builder(getActivity())
                .setCancelable(false)
                .setSpinnerClockwise(false)
                .setMessageContentGravity(Gravity.END)
                .build();


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        webView.setVisibility(View.VISIBLE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);

        webView.clearHistory();
        webView.clearFormData();
        webView.clearCache(true);

        webView.loadUrl(url);
        webView.setWebViewClient(new MyWebViewClient());
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progressCount) {
                if (progressCount > 90) {
                }
//                    mProgress.setVisibility(View.GONE);
            }
        });
        if (Build.VERSION.SDK_INT >= 21) {
            webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        return view;
    }

    private class MyWebViewClient extends WebViewClient {
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.d("url<<>!<>!<>!<>!<>!<>>", " " + url);
            if (loaded == 1) {
                if (url.contains("https://www.tiktalkapp.com/")) {
                    Log.e("loaded_url", url.toString());
                    String[] splitURLArray = url.split("https://www.tiktalkapp.com/");
                    String strResult = "";
                    if (splitURLArray.length > 1) {
                        strResult = splitURLArray[1];
                        saveResultToServer(strResult);
                    }
                    view.clearHistory();
                    view.clearFormData();
                    view.clearCache(true);
                    view.loadUrl(url);
                } else {
                    view.clearHistory();
                    view.clearFormData();
                    view.clearCache(true);
                    view.loadUrl(url);
                }
            } else {
                view.clearHistory();
                view.clearFormData();
                view.clearCache(true);
                view.loadUrl(url);
            }
            loaded = 1;
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            //   view.loadUrl(url);
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            try {
                Toast.makeText(getActivity(), "Please check internet connection.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
            }
        }


        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        }

        @Override
        public void onReceivedHttpError(
                WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            // showError(" SslError "+error);
        }
    }

    public void saveResultToServer(String strResult) {
        Log.e("user_test_result", strResult);
        if (getResult(strResult).equals("")) {
            Toast.makeText(getActivity(), getActivity().getResources().getString(R.string.try_again_for_result), Toast.LENGTH_SHORT).show();
        } else {
            callTestResult_Saving_Api(MainMenuActivity.user_id, getResult(strResult));
        }
    }

    private String getResult(String resultVal) {
        resultValue = "";
        if (resultVal.equals("aaa"))
            resultValue = "A";
        else if (resultVal.equals("bbb"))
            resultValue = "B";
        else if (resultVal.equals("eee"))
            resultValue = "E";
        else if (resultVal.equals("iii"))
            resultValue = "I";
        else if (resultVal.equals("mmm"))
            resultValue = "M";
        else if (resultVal.equals("fff"))
            resultValue = "F";
        else if (resultVal.equals("jjj"))
            resultValue = "J";
        else if (resultVal.equals("nnn"))
            resultValue = "N";
        else if (resultVal.equals("ccc"))
            resultValue = "C";
        else if (resultVal.equals("ddd"))
            resultValue = "D";
        else if (resultVal.equals("ggg"))
            resultValue = "G";
        else if (resultVal.equals("hhh"))
            resultValue = "H";
        else if (resultVal.equals("kkk"))
            resultValue = "K";
        else if (resultVal.equals("lll"))
            resultValue = "L";
        else if (resultVal.equals("ooo"))
            resultValue = "O";
        else if (resultVal.equals("ppp"))
            resultValue = "P";

        return resultValue;
    }


    private void callTestResult_Saving_Api(String user_id, final String result) {
        JSONObject parameters = new JSONObject();
        try {
            parameters.put("fb_id", MainMenuActivity.user_id);
            parameters.put("test_result", result);
            Log.e("parametsds", parameters.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue rq = Volley.newRequestQueue(getActivity());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, Variables.savetestResult, parameters, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        String respo = response.toString();
                        Log.d("responce", respo);
                        iosDialog.cancel();
                        MainMenuActivity.sharedPreferences.edit().putString(Variables.test_result, result).commit();
                        Parse_signup_data(respo);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        iosDialog.cancel();
                        Toast.makeText(getActivity(), "Somthing Wrong with Api", Toast.LENGTH_LONG).show();
                        Log.d("respo", error.toString());
                    }
                });
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        rq.getCache().clear();
        rq.add(jsonObjectRequest);
    }


    public void Parse_signup_data(String loginData) {
        try {
            JSONObject jsonObject = new JSONObject(loginData);
            String code = jsonObject.optString("code");
            if (code.equals("200")) {
                MainMenuActivity.sharedPreferences.edit().putString(Variables.test_result, resultValue).commit();
                Toast.makeText(getActivity(), jsonObject.getString("msg"), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getActivity(), "Please try again", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            iosDialog.cancel();
            e.printStackTrace();
        }

    }

}
