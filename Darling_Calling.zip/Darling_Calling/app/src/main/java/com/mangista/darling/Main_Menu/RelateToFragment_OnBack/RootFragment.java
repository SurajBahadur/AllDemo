package com.mangista.darling.Main_Menu.RelateToFragment_OnBack;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;

import com.mangista.darling.sinch.BaseActivity;
import com.mangista.darling.sinch.SinchService;

import static android.content.Context.BIND_AUTO_CREATE;



public class RootFragment extends Fragment implements OnBackPressListener, ServiceConnection {
    private SinchService.SinchServiceInterface mSinchServiceInterface;

    @Override
    public boolean onBackPressed() {
        return new BackPressImplimentation(this).onBackPressed();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bindService();
    }

    @Override
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        if (SinchService.class.getName().equals(componentName.getClassName())) {
            mSinchServiceInterface = (SinchService.SinchServiceInterface) iBinder;
            onServiceConnected();
            Log.e("sinch_service","empty_28");
        }else{
            Log.e("sinch_service","empty_30");
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName componentName) {
        if (SinchService.class.getName().equals(componentName.getClassName())) {
            mSinchServiceInterface = null;
            onServiceDisconnected();
            Log.e("sinch_service","empty_39");
        }else{
            Log.e("sinch_service","empty_41");
        }
    }

    protected void onServiceConnected() {
        // for subclasses
    }

    protected void onServiceDisconnected() {
        // for subclasses
    }

    protected SinchService.SinchServiceInterface getSinchServiceInterface() {
        return mSinchServiceInterface;
    }

    private void bindService() {
        Intent serviceIntent = new Intent(getActivity(), SinchService.class);
        serviceIntent.putExtra(SinchService.MESSENGER, messenger);
        getActivity().bindService(serviceIntent, this, BIND_AUTO_CREATE);
    }


    private Messenger messenger = new Messenger(new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SinchService.MESSAGE_PERMISSIONS_NEEDED:
                    Bundle bundle = msg.getData();
                    String requiredPermission = bundle.getString(SinchService.REQUIRED_PERMISSION);
                    ActivityCompat.requestPermissions(getActivity(), new String[]{requiredPermission}, 0);
                    break;
            }
        }
    });
}