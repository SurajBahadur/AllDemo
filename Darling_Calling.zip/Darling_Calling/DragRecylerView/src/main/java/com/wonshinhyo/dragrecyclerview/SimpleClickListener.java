package com.wonshinhyo.dragrecyclerview;

import android.view.View;

/**
 * Created by Shinhyo on 2016. 6. 13..
 */
public class SimpleClickListener implements OnClickListener {

    @Override
    public void onItemClick(View v, int position) {

    }

    @Override
    public void onItemLongClick(View v, int position) {

    }
}
