package com.wonshinhyo.dragrecyclerview;

/**
 * Created by Shinhyo on 2016. 6. 14..
 */

public interface ImpAdapter {

    void setHandleId(int handleId);

    void setRecycleView(DragRecyclerView recyclerView);
}
