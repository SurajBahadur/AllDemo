package com.wonshinhyo.dragrecyclerview;

/**
 * Created by Shinhyo on 2016. 6. 15..
 */

public interface ImpRecycleView {

    void setAdapter(android.support.v7.widget.RecyclerView.Adapter adapter);
}
